package com.tourism;
import java.util.Map;
import java.util.HashMap;
import java.util.Random;

public class Authentication {
    private Map<String, User> users = new HashMap<>();
    private Map<String, Integer> mobileOtpMap = new HashMap<>();
    private int userIdCounter = 1; // Initialize a counter for unique IDs

    public void signUp(String name, String email, String mobile, String password) {
        int otp = generateOTP();
        mobileOtpMap.put(mobile, otp);

        String userId = "U" + userIdCounter++; // Generate unique user ID
        User newUser = new User(userId, name, email, mobile, password);
        users.put(email, newUser);

        System.out.println("Sign up successful! You can now log in.");
    }

    public User logIn(String email, String password) {
        User user = users.get(email);

        if (user != null && user.password.equals(password)) {
            return user;
        }

        System.out.println("Invalid email or password. Please try again.");
        return null;
    }

    private int generateOTP() {
        Random random = new Random();
        return 100000 + random.nextInt(900000);
    }
}
