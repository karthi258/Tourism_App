package com.tourism;

import java.util.Scanner;

public class ChatBox {
    public void startChat(User currentUser) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Chat started. Type 'exit' to end.");
        while (true) {
            System.out.print(currentUser.name + ": ");
            String input = scanner.nextLine();

            if (input.equalsIgnoreCase("exit")) {
                System.out.println("Chat ended.");
                break;
            }

            String response = generateResponse(input);
            System.out.println("Bot: " + response);
        }
    }

    private String generateResponse(String input) {
        return "You said: " + input;
    }
}
