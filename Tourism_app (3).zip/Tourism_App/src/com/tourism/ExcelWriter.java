package com.tourism;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

public class ExcelWriter {
    public static void writeBookingsToExcel(List<Booking> bookings, String filePath) {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Bookings");
        int rowCount = 0;

        for (Booking booking : bookings) {
            Row row = sheet.createRow(rowCount++);
            int cellCount = 0;

            Cell cell = row.createCell(cellCount++);
            cell.setCellValue(booking.getName());

            cell = row.createCell(cellCount++);
            cell.setCellValue(booking.getDestination());

            cell = row.createCell(cellCount++);
            cell.setCellValue(booking.getDate());

            cell = row.createCell(cellCount);
            cell.setCellValue(booking.getAmount());
        }

        try (FileOutputStream fileOut = new FileOutputStream(filePath)) {
            workbook.write(fileOut);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
