package com.tourism;
public class User {
    String id; // Add this field for unique ID
    String name;
    String email;
    String mobile;
    String password;

    public User(String id, String name, String email, String mobile, String password) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.mobile = mobile;
        this.password = password;
    }
}
