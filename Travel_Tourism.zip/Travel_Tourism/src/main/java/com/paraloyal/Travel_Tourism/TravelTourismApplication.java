package com.paraloyal.Travel_Tourism;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelTourismApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelTourismApplication.class, args);
	}

}
