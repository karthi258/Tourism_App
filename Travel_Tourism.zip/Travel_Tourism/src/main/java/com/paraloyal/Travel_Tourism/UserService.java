package com.paraloyal.Travel_Tourism;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class UserService {

    // Simulating a database with user information
    private Map<String, String> userDatabase = new HashMap<>();

    @Autowired
    public UserService() {
        // For demonstration purposes, adding a sample user
        userDatabase.put("john@example.com", "password123");
    }

    public boolean registerUser(String email, String password) {
        if (!userDatabase.containsKey(email)) {
            userDatabase.put(email, password);
            return true;
        }
        return false;
    }

    public boolean authenticateUser(String email, String password) {
        if (userDatabase.containsKey(email) && userDatabase.get(email).equals(password)) {
            return true;
        }
        return false;
    }
}