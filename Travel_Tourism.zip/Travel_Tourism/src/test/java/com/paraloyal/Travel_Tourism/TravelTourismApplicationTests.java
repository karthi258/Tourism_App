package com.paraloyal.Travel_Tourism;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelTourismApplicationTests {

	@Test
	void contextLoads() {
	}

}
